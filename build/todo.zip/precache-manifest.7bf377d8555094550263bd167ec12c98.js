self.__precacheManifest = [
  {
    "revision": "5cf4497e6be9b4a0032b",
    "url": "/static/css/main.a6ccee36.chunk.css"
  },
  {
    "revision": "5cf4497e6be9b4a0032b",
    "url": "/static/js/main.ac2b027a.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "dd89eb0967c53cce9ce9",
    "url": "/static/js/2.068d55d8.chunk.js"
  },
  {
    "revision": "ae5f59f1f005ef2f7a9322ec4ec6b20a",
    "url": "/index.html"
  }
];